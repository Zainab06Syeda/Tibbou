import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Clock, DollarSign, Layers } from "lucide-react";

const matColors = {
  view: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  table: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  incremental: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  ephemeral: "bg-purple-500/10 text-purple-400 border-purple-500/20",
};

export default function ModelCard({ model }) {
  return (
    <div className="bg-card border border-border rounded-xl p-5 hover:border-primary/30 transition-all duration-300 group">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
            {model.model_name}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {model.database_name ? `${model.database_name}.${model.schema_name}` : model.schema_name || "—"}
          </p>
        </div>
        <Badge variant="outline" className={cn("text-xs", matColors[model.materialization])}>
          {model.materialization}
        </Badge>
      </div>

      {model.description && (
        <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{model.description}</p>
      )}

      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        {model.avg_run_time_seconds !== undefined && (
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{model.avg_run_time_seconds?.toFixed(1)}s</span>
          </div>
        )}
        {model.avg_cost_credits !== undefined && (
          <div className="flex items-center gap-1">
            <DollarSign className="w-3 h-3" />
            <span>{model.avg_cost_credits?.toFixed(3)} credits</span>
          </div>
        )}
        {model.depends_on?.length > 0 && (
          <div className="flex items-center gap-1">
            <Layers className="w-3 h-3" />
            <span>{model.depends_on.length} deps</span>
          </div>
        )}
      </div>

      {model.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-3">
          {model.tags.map((tag) => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
              {tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}