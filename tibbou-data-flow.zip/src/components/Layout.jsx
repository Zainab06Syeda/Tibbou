import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";

export default function Layout() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto flex flex-col">
        <TopBar />
        <div className="p-6 lg:p-8 max-w-[1400px] mx-auto w-full flex-1">
          <Outlet />
        </div>
      </main>
    </div>
  );
}