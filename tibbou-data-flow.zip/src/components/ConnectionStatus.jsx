import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Wifi, WifiOff, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ConnectionStatus({ collapsed }) {
  const [connection, setConnection] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const user = await base44.auth.me();
        const conns = await base44.entities.SnowflakeConnection.filter({ user_email: user.email, is_active: true });
        setConnection(conns[0] || null);
      } catch {
        setConnection(null);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="px-3 py-2 flex items-center gap-2">
        <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
        {!collapsed && <span className="text-xs text-muted-foreground">Checking...</span>}
      </div>
    );
  }

  const isConnected = connection?.connection_status === "connected";

  return (
    <div className={cn(
      "mx-3 mb-3 px-3 py-2 rounded-lg border text-xs flex items-center gap-2",
      isConnected
        ? "bg-emerald-500/10 border-emerald-500/20"
        : "bg-amber-500/10 border-amber-500/20"
    )}>
      {isConnected
        ? <Wifi className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
        : <WifiOff className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />}
      {!collapsed && (
        <div className="overflow-hidden">
          <p className={cn("font-medium truncate", isConnected ? "text-emerald-400" : "text-amber-400")}>
            {isConnected ? connection.connection_name || connection.account_identifier : "No Connection"}
          </p>
          {!isConnected && <p className="text-muted-foreground/60">Connect Snowflake →</p>}
        </div>
      )}
    </div>
  );
}