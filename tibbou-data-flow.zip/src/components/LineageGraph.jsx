import { useState, useMemo, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Database, Boxes, Eye, TestTube, Camera } from "lucide-react";

const nodeTypeConfig = {
  source: { color: "bg-emerald-500/20 border-emerald-500/40 text-emerald-400", icon: Database, label: "Source" },
  model: { color: "bg-primary/20 border-primary/40 text-primary", icon: Boxes, label: "Model" },
  exposure: { color: "bg-amber-500/20 border-amber-500/40 text-amber-400", icon: Eye, label: "Exposure" },
  test: { color: "bg-purple-500/20 border-purple-500/40 text-purple-400", icon: TestTube, label: "Test" },
  seed: { color: "bg-blue-500/20 border-blue-500/40 text-blue-400", icon: Database, label: "Seed" },
  snapshot: { color: "bg-orange-500/20 border-orange-500/40 text-orange-400", icon: Camera, label: "Snapshot" },
};

function getNodeType(nodeName, edges) {
  for (const edge of edges) {
    if (edge.source_node === nodeName) return edge.source_type;
    if (edge.target_node === nodeName) return edge.target_type;
  }
  return "model";
}

export default function LineageGraph({ edges = [] }) {
  const [selectedNode, setSelectedNode] = useState(null);

  const { nodes, levels } = useMemo(() => {
    if (!edges.length) return { nodes: new Map(), levels: [] };

    const allNodes = new Set();
    const incoming = new Map();
    const outgoing = new Map();

    edges.forEach((e) => {
      allNodes.add(e.source_node);
      allNodes.add(e.target_node);
      if (!outgoing.has(e.source_node)) outgoing.set(e.source_node, []);
      outgoing.get(e.source_node).push(e.target_node);
      if (!incoming.has(e.target_node)) incoming.set(e.target_node, []);
      incoming.get(e.target_node).push(e.source_node);
    });

    // Topological levels
    const roots = [...allNodes].filter((n) => !incoming.has(n) || incoming.get(n).length === 0);
    const visited = new Set();
    const levelMap = new Map();
    const queue = roots.map((r) => ({ node: r, level: 0 }));

    while (queue.length) {
      const { node, level } = queue.shift();
      if (visited.has(node)) continue;
      visited.add(node);
      levelMap.set(node, level);
      const children = outgoing.get(node) || [];
      children.forEach((c) => queue.push({ node: c, level: level + 1 }));
    }

    // Assign unvisited nodes
    allNodes.forEach((n) => {
      if (!visited.has(n)) levelMap.set(n, 0);
    });

    const maxLevel = Math.max(...levelMap.values(), 0);
    const lvls = [];
    for (let i = 0; i <= maxLevel; i++) {
      lvls.push([...allNodes].filter((n) => levelMap.get(n) === i));
    }

    const nodeMap = new Map();
    const colWidth = 220;
    const rowHeight = 72;

    lvls.forEach((level, li) => {
      level.forEach((name, ni) => {
        const type = getNodeType(name, edges);
        nodeMap.set(name, {
          name,
          type,
          x: li * colWidth + 40,
          y: ni * rowHeight + 40,
        });
      });
    });

    return { nodes: nodeMap, levels: lvls };
  }, [edges]);

  const handleNodeClick = useCallback((name) => {
    setSelectedNode(selectedNode === name ? null : name);
  }, [selectedNode]);

  if (!edges.length) {
    return (
      <div className="bg-card border border-border rounded-xl p-12 flex flex-col items-center justify-center text-center">
        <Boxes className="w-12 h-12 text-muted-foreground/30 mb-4" />
        <p className="text-muted-foreground text-sm">No lineage data available</p>
        <p className="text-muted-foreground/60 text-xs mt-1">Add lineage edges to visualize your data flow</p>
      </div>
    );
  }

  const maxX = Math.max(...[...nodes.values()].map((n) => n.x)) + 220;
  const maxY = Math.max(...[...nodes.values()].map((n) => n.y)) + 80;

  // Highlight connected nodes
  const connectedNodes = new Set();
  if (selectedNode) {
    connectedNodes.add(selectedNode);
    edges.forEach((e) => {
      if (e.source_node === selectedNode) connectedNodes.add(e.target_node);
      if (e.target_node === selectedNode) connectedNodes.add(e.source_node);
    });
  }

  return (
    <div className="bg-card border border-border rounded-xl overflow-auto">
      <svg width={maxX} height={maxY} className="min-w-full">
        <defs>
          <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="hsl(var(--primary))" opacity="0.5" />
          </marker>
          <marker id="arrowhead-active" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="hsl(var(--primary))" />
          </marker>
        </defs>

        {/* Edges */}
        {edges.map((edge, i) => {
          const src = nodes.get(edge.source_node);
          const tgt = nodes.get(edge.target_node);
          if (!src || !tgt) return null;

          const isHighlighted = selectedNode && connectedNodes.has(edge.source_node) && connectedNodes.has(edge.target_node);
          const isDimmed = selectedNode && !isHighlighted;

          return (
            <line
              key={i}
              x1={src.x + 160}
              y1={src.y + 24}
              x2={tgt.x}
              y2={tgt.y + 24}
              stroke={isHighlighted ? "hsl(var(--primary))" : "hsl(var(--border))"}
              strokeWidth={isHighlighted ? 2 : 1}
              strokeDasharray={isHighlighted ? "none" : "4 4"}
              opacity={isDimmed ? 0.15 : isHighlighted ? 1 : 0.4}
              markerEnd={isHighlighted ? "url(#arrowhead-active)" : "url(#arrowhead)"}
              className="transition-all duration-300"
            />
          );
        })}

        {/* Nodes */}
        {[...nodes.values()].map((node) => {
          const config = nodeTypeConfig[node.type] || nodeTypeConfig.model;
          const Icon = config.icon;
          const isSelected = selectedNode === node.name;
          const isConnected = connectedNodes.has(node.name);
          const isDimmed = selectedNode && !isConnected;

          return (
            <foreignObject
              key={node.name}
              x={node.x}
              y={node.y}
              width={160}
              height={48}
              className="cursor-pointer"
              onClick={() => handleNodeClick(node.name)}
            >
              <div
                className={cn(
                  "h-full rounded-lg border px-3 flex items-center gap-2 transition-all duration-300",
                  config.color,
                  isSelected && "ring-2 ring-primary shadow-lg shadow-primary/10",
                  isDimmed && "opacity-20"
                )}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <div className="overflow-hidden">
                  <p className="text-xs font-medium truncate text-foreground">{node.name}</p>
                  <p className="text-[10px] opacity-60">{config.label}</p>
                </div>
              </div>
            </foreignObject>
          );
        })}
      </svg>
    </div>
  );
}