import { cn } from "@/lib/utils";

export default function StatsCard({ title, value, subtitle, icon: Icon, trend, trendLabel, className }) {
  const isPositiveTrend = trend && trend > 0;
  const isNegativeTrend = trend && trend < 0;

  return (
    <div className={cn(
      "bg-card border border-border rounded-xl p-5 transition-all duration-300 hover:border-primary/30 group",
      className
    )}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-sm text-muted-foreground font-medium">{title}</p>
        {Icon && (
          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
            <Icon className="w-4 h-4 text-primary" />
          </div>
        )}
      </div>
      <p className="text-2xl font-bold text-foreground tracking-tight">{value}</p>
      <div className="flex items-center gap-2 mt-2">
        {trend !== undefined && (
          <span className={cn(
            "text-xs font-medium px-1.5 py-0.5 rounded",
            isPositiveTrend && "bg-red-500/10 text-red-400",
            isNegativeTrend && "bg-emerald-500/10 text-emerald-400",
            !isPositiveTrend && !isNegativeTrend && "bg-muted text-muted-foreground"
          )}>
            {isPositiveTrend ? "↑" : isNegativeTrend ? "↓" : "→"} {Math.abs(trend)}%
          </span>
        )}
        {(subtitle || trendLabel) && (
          <span className="text-xs text-muted-foreground">{trendLabel || subtitle}</span>
        )}
      </div>
    </div>
  );
}