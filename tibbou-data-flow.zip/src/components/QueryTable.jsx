import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import moment from "moment";

const statusColors = {
  SUCCESS: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  FAIL: "bg-red-500/10 text-red-400 border-red-500/20",
  RUNNING: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  QUEUED: "bg-amber-500/10 text-amber-400 border-amber-500/20",
};

function formatDuration(ms) {
  if (!ms) return "—";
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
}

function formatBytes(bytes) {
  if (!bytes) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${(bytes / 1073741824).toFixed(1)} GB`;
}

export default function QueryTable({ queries = [] }) {
  if (!queries.length) {
    return (
      <div className="bg-card border border-border rounded-xl p-8 text-center">
        <p className="text-muted-foreground text-sm">No queries found</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Query</th>
              <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Status</th>
              <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Warehouse</th>
              <th className="text-right text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Duration</th>
              <th className="text-right text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Credits</th>
              <th className="text-right text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Scanned</th>
              <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Time</th>
            </tr>
          </thead>
          <tbody>
            {queries.map((q, i) => (
              <tr
                key={q.id || i}
                className="border-b border-border/50 hover:bg-secondary/30 transition-colors"
              >
                <td className="px-5 py-3.5">
                  <p className="text-sm text-foreground font-mono truncate max-w-[300px]">
                    {q.query_text?.substring(0, 60)}...
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">{q.query_type || "—"} · {q.user_name || "—"}</p>
                </td>
                <td className="px-5 py-3.5">
                  <Badge variant="outline" className={cn("text-xs", statusColors[q.status])}>
                    {q.status}
                  </Badge>
                </td>
                <td className="px-5 py-3.5">
                  <span className="text-sm text-foreground">{q.warehouse_name}</span>
                </td>
                <td className="px-5 py-3.5 text-right">
                  <span className="text-sm text-foreground font-mono">{formatDuration(q.duration_ms)}</span>
                </td>
                <td className="px-5 py-3.5 text-right">
                  <span className="text-sm text-primary font-mono">{q.credits_used?.toFixed(3) || "—"}</span>
                </td>
                <td className="px-5 py-3.5 text-right">
                  <span className="text-sm text-muted-foreground font-mono">{formatBytes(q.bytes_scanned)}</span>
                </td>
                <td className="px-5 py-3.5">
                  <span className="text-xs text-muted-foreground">
                    {q.start_time ? moment(q.start_time).fromNow() : "—"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}