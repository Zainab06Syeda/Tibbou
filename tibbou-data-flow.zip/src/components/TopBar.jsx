import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Bell, ChevronDown, Settings, LogOut, User } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const MOCK_NOTIFICATIONS = [
  { id: 1, title: "fct_revenue run failed", desc: "Merge conflict: duplicate keys found", time: "2m ago", read: false, type: "error" },
  { id: 2, title: "Snowflake sync complete", desc: "COMPUTE_WH synced 245 queries", time: "1h ago", read: false, type: "success" },
  { id: 3, title: "New dbt run started", desc: "tibbou_dbt pipeline running...", time: "2h ago", read: true, type: "info" },
];

export default function TopBar() {
  const [user, setUser] = useState(null);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  function markAllRead() {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }

  const typeColors = {
    error: "bg-red-500",
    success: "bg-emerald-500",
    info: "bg-primary",
  };

  return (
    <header className="h-14 border-b border-border bg-card/60 backdrop-blur flex items-center justify-end px-6 gap-3 sticky top-0 z-10">
      {/* Notifications */}
      <DropdownMenu open={notifOpen} onOpenChange={setNotifOpen}>
        <DropdownMenuTrigger asChild>
          <button className="relative w-9 h-9 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            <Bell className="w-4.5 h-4.5 w-[18px] h-[18px]" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 ring-2 ring-card" />
            )}
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-80 bg-card border-border p-0">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <p className="text-sm font-semibold text-foreground">Notifications</p>
            {unreadCount > 0 && (
              <button onClick={markAllRead} className="text-xs text-primary hover:underline">Mark all read</button>
            )}
          </div>
          <div className="max-h-72 overflow-y-auto">
            {notifications.map(n => (
              <div
                key={n.id}
                onClick={() => setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x))}
                className={cn(
                  "px-4 py-3 border-b border-border/50 last:border-0 cursor-pointer hover:bg-secondary/40 transition-colors",
                  !n.read && "bg-secondary/20"
                )}
              >
                <div className="flex items-start gap-3">
                  <div className={cn("w-2 h-2 rounded-full mt-1.5 flex-shrink-0", typeColors[n.type])} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground leading-tight">{n.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{n.desc}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground flex-shrink-0">{n.time}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="px-4 py-2.5 border-t border-border">
            <p className="text-xs text-muted-foreground text-center">No more notifications</p>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* User menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg hover:bg-secondary transition-colors">
            <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold text-xs">
              {user?.full_name?.[0]?.toUpperCase() || "?"}
            </div>
            <span className="text-sm font-medium text-foreground hidden sm:block">
              {user?.full_name?.split(" ")[0] || "User"}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-52 bg-card border-border">
          <div className="px-3 py-2.5 border-b border-border">
            <p className="text-sm font-semibold text-foreground">{user?.full_name}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
          <Link to="/settings">
            <DropdownMenuItem className="cursor-pointer text-sm gap-2">
              <User className="w-4 h-4" /> Profile & Settings
            </DropdownMenuItem>
          </Link>
          <DropdownMenuSeparator className="bg-border" />
          <DropdownMenuItem
            className="cursor-pointer text-sm gap-2 text-destructive focus:text-destructive"
            onClick={() => base44.auth.logout()}
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}