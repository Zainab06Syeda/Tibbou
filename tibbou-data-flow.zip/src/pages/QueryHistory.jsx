import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, AlertTriangle, ArrowRight } from "lucide-react";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { cn } from "@/lib/utils";

const SAMPLE_QUERIES = [
  { query_id: "Q1934", user_name: "analytics_user", warehouse_name: "WH_L", duration_ms: 12000, credits_used: 4.32, status: "SUCCESS" },
  { query_id: "Q2031", user_name: "data_engineer", warehouse_name: "WH_XL", duration_ms: 22000, credits_used: 6.10, status: "SUCCESS" },
  { query_id: "Q2201", user_name: "analyst_user", warehouse_name: "WH_M", duration_ms: 5000, credits_used: 1.20, status: "SUCCESS" },
  { query_id: "Q3015", user_name: "data_scientist", warehouse_name: "WH_L", duration_ms: 35000, credits_used: 6.80, status: "RUNNING" },
  { query_id: "Q1172", user_name: "analyst_user", warehouse_name: "WH_XE", duration_ms: 34000, credits_used: 3.20, status: "SUCCESS" },
];

const QUERY_ALERTS = [
  "Query Q2012 took 345s to execute",
  "Query Q1934 cost 3X higher than average",
  "Warehouse WH_XL under heavy load",
];

const PIE_DATA = [
  { name: "Small", value: 27 },
  { name: "Medium", value: 53 },
  { name: "Large", value: 20 },
];

const PIE_COLORS = ["hsl(217,19%,35%)", "hsl(215,20%,55%)", "hsl(215,20%,75%)"];

function formatDuration(ms) {
  if (!ms) return "—";
  return `${Math.round(ms / 1000)}s`;
}

export default function QueryHistory() {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterDate, setFilterDate] = useState("7d");
  const [filterUser, setFilterUser] = useState("all");
  const [filterWarehouse, setFilterWarehouse] = useState("all");

  useEffect(() => {
    async function load() {
      const data = await base44.entities.SnowflakeQuery.list("-start_time", 200);
      setQueries(data.length > 0 ? data : SAMPLE_QUERIES);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const users = [...new Set(queries.map(q => q.user_name).filter(Boolean))];
  const warehouses = [...new Set(queries.map(q => q.warehouse_name).filter(Boolean))];

  const filtered = queries.filter(q => {
    const matchSearch = !search ||
      q.query_id?.toLowerCase().includes(search.toLowerCase()) ||
      q.user_name?.toLowerCase().includes(search.toLowerCase());
    const matchUser = filterUser === "all" || q.user_name === filterUser;
    const matchWH = filterWarehouse === "all" || q.warehouse_name === filterWarehouse;
    return matchSearch && matchUser && matchWH;
  });

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold text-foreground tracking-tight">Query Monitoring</h1>

      {/* Filter bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-sm text-muted-foreground">Filter by:</span>
        <Select value={filterDate} onValueChange={setFilterDate}>
          <SelectTrigger className="h-8 text-xs bg-card border-border w-[110px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="1d">Last 1 Day</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterUser} onValueChange={setFilterUser}>
          <SelectTrigger className="h-8 text-xs bg-card border-border w-[110px]"><SelectValue placeholder="User" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Users</SelectItem>
            {users.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterWarehouse} onValueChange={setFilterWarehouse}>
          <SelectTrigger className="h-8 text-xs bg-card border-border w-[120px]"><SelectValue placeholder="Warehouse" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Warehouses</SelectItem>
            {warehouses.map(w => <SelectItem key={w} value={w}>{w}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="relative ml-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search queries"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-8 h-8 text-xs bg-card border-border w-[200px]"
          />
        </div>
      </div>

      {/* Two-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Active Queries + Alerts */}
        <div className="lg:col-span-2 space-y-4">
          {/* Active Queries */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border">
              <h2 className="text-sm font-semibold text-foreground">Active Queries</h2>
              <p className="text-xs text-muted-foreground mt-0.5">{filtered.length * 84} Queries in Last 7 Days</p>
            </div>
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/20">
                  <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Query ID</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">User</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Warehouse</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Execution</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Cost</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 8).map((q, i) => (
                  <tr key={q.id || i} className="border-b border-border/50 hover:bg-secondary/20 transition-colors">
                    <td className="px-5 py-3 text-sm font-mono text-foreground">{q.query_id}</td>
                    <td className="px-5 py-3 text-sm text-muted-foreground">{q.user_name}</td>
                    <td className="px-5 py-3 text-sm text-muted-foreground">{q.warehouse_name}</td>
                    <td className="px-5 py-3 text-sm text-foreground">{formatDuration(q.duration_ms)}</td>
                    <td className="px-5 py-3 text-sm text-foreground">${(q.credits_used || 0).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Query Alerts */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="text-sm font-semibold text-foreground mb-3">Query Alerts</h2>
            <div className="space-y-2">
              {QUERY_ALERTS.map((a, i) => (
                <div key={i} className="flex items-center gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <p className="text-xs text-muted-foreground">{a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Pie chart + Alerts summary */}
        <div className="space-y-4">
          {/* Query Cost Distribution */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="text-sm font-semibold text-foreground mb-3">Query Cost Distribution</h2>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={PIE_DATA} cx="50%" cy="50%" innerRadius={0} outerRadius={75} dataKey="value" startAngle={90} endAngle={-270}>
                    {PIE_DATA.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v) => `${v}%`} contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-4 mt-1">
              {PIE_DATA.map((d, i) => (
                <div key={d.name} className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ background: PIE_COLORS[i] }} />
                  <span className="text-xs text-muted-foreground">{d.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Alerts panel */}
          <div className="bg-card border border-border rounded-xl p-5 space-y-3">
            <div className="space-y-1 text-xs text-muted-foreground">
              <p><span className="text-foreground font-medium">Date:</span> Last 7 Days</p>
              <p><span className="text-foreground font-medium">User:</span> Selected</p>
              <p><span className="text-foreground font-medium">Warehouse:</span> Selected</p>
            </div>
            <div className="border-t border-border pt-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-semibold text-foreground">Alerts</h3>
                <button className="text-xs text-primary hover:underline flex items-center gap-1">
                  View All <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-2">
                {QUERY_ALERTS.map((a, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">{a}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}