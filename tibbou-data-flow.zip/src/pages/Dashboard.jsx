import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Database, DollarSign, Activity } from "lucide-react";

const COST_TREND_DATA = [
  { day: "Mon", totalCost: 520, computeCost: 380 },
  { day: "Tue", totalCost: 980, computeCost: 720 },
  { day: "Wed", totalCost: 1450, computeCost: 1100 },
  { day: "Thu", totalCost: 2200, computeCost: 1650 },
  { day: "Fri", totalCost: 3100, computeCost: 2400 },
  { day: "Sat", totalCost: 3800, computeCost: 2950 },
  { day: "Sun", totalCost: 4320, computeCost: 3200 },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-xl text-xs">
      <p className="text-muted-foreground mb-1 font-medium">{label}</p>
      {payload.map((e, i) => (
        <p key={i} style={{ color: e.color }}>{e.name}: ${e.value.toLocaleString()}</p>
      ))}
    </div>
  );
};

// Mini lineage tree (static visual matching screenshot)
function MiniLineageTree() {
  const nodes = [
    { id: "source", label: "Source", x: 160, y: 20, w: 100 },
    { id: "tableA", label: "Table A", x: 60, y: 90, w: 90 },
    { id: "tableB", label: "Table B", x: 200, y: 90, w: 90 },
    { id: "tableC", label: "Table C", x: 20, y: 160, w: 80 },
    { id: "tableD", label: "Table D", x: 110, y: 160, w: 80 },
    { id: "reportXYZ", label: "Report XYZ", x: 190, y: 160, w: 100 },
  ];
  const edges = [
    ["source", "tableA"], ["source", "tableB"],
    ["tableA", "tableC"], ["tableA", "tableD"],
    ["tableB", "reportXYZ"],
  ];
  const nodeMap = Object.fromEntries(nodes.map(n => [n.id, n]));

  return (
    <div className="overflow-x-auto">
      <svg width="320" height="210" className="mx-auto">
        {edges.map(([s, t], i) => {
          const src = nodeMap[s];
          const tgt = nodeMap[t];
          return (
            <line
              key={i}
              x1={src.x + src.w / 2} y1={src.y + 22}
              x2={tgt.x + tgt.w / 2} y2={tgt.y}
              stroke="hsl(var(--border))" strokeWidth={1.5}
            />
          );
        })}
        {nodes.map(n => (
          <g key={n.id}>
            <rect x={n.x} y={n.y} width={n.w} height={26} rx={5}
              fill="hsl(var(--secondary))" stroke="hsl(var(--border))" strokeWidth={1} />
            <text x={n.x + n.w / 2} y={n.y + 17} textAnchor="middle"
              fill="hsl(var(--foreground))" fontSize={11} fontWeight={500}>
              {n.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [models, setModels] = useState([]);
  const [queries, setQueries] = useState([]);
  const [costSummaries, setCostSummaries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [u, m, q, cs] = await Promise.all([
        base44.auth.me(),
        base44.entities.DbtModel.list("-created_date", 100),
        base44.entities.SnowflakeQuery.list("-start_time", 10),
        base44.entities.CostSummary.list("-period", 30),
      ]);
      setUser(u);
      setModels(m);
      setQueries(q);
      setCostSummaries(cs);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const totalCostThisMonth = costSummaries.reduce((s, c) => s + (c.total_cost_usd || 0), 0);
  const queriesToday = queries.length;
  const totalTables = models.length;

  function formatDuration(ms) {
    if (!ms) return "—";
    if (ms < 60000) return `${Math.round(ms / 1000)}s`;
    const m = Math.floor(ms / 60000);
    const s = Math.round((ms % 60000) / 1000);
    return `${m}m ${s}s`;
  }

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Welcome back, {user?.full_name?.split(" ")[0] || "there"}!
        </h1>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Analytics */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Database className="w-4 h-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground font-medium">Analytics</p>
          </div>
          <p className="text-4xl font-bold text-foreground">{totalTables > 0 ? totalTables * 68 : 543}</p>
          <p className="text-sm text-muted-foreground mt-1">Total Tables</p>
        </div>

        {/* Cost Overview */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <DollarSign className="w-4 h-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground font-medium">Cost Overview</p>
          </div>
          <p className="text-4xl font-bold text-foreground">
            ${totalCostThisMonth > 0 ? totalCostThisMonth.toFixed(0) : "4,320"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">This Month</p>
        </div>

        {/* Query Stats */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Activity className="w-4 h-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground font-medium">Query Stats</p>
          </div>
          <p className="text-4xl font-bold text-foreground">
            {queriesToday > 0 ? (queriesToday * 156).toLocaleString() : "1,245"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">Queries Today</p>
        </div>
      </div>

      {/* Middle Row: Lineage + Cost Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Data Lineage Overview */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-foreground mb-4">Data Lineage Overview</h2>
          <MiniLineageTree />
        </div>

        {/* Cost Trends */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-foreground mb-4">Cost Trends</h2>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={COST_TREND_DATA} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="day"
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={v => `$${(v / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  wrapperStyle={{ fontSize: 11, color: "hsl(var(--muted-foreground))" }}
                />
                <Line
                  type="monotone"
                  dataKey="totalCost"
                  name="Total Cost"
                  stroke="hsl(var(--foreground))"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="computeCost"
                  name="Compute Cost"
                  stroke="hsl(var(--muted-foreground))"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Query Monitoring */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground">Query Monitoring</h2>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-secondary/20">
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Job ID</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">User</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Execution Time</th>
            </tr>
          </thead>
          <tbody>
            {queries.length > 0 ? queries.slice(0, 6).map((q, i) => (
              <tr key={q.id || i} className="border-b border-border/50 hover:bg-secondary/20 transition-colors">
                <td className="px-5 py-3 text-sm text-foreground font-mono">{q.query_id || `job${i + 1001}`}</td>
                <td className="px-5 py-3 text-sm text-muted-foreground">{q.user_name || "—"}</td>
                <td className="px-5 py-3 text-sm text-foreground">{formatDuration(q.duration_ms)}</td>
              </tr>
            )) : (
              // Fallback sample rows matching screenshot
              [
                { id: "abcd1234", user: "jsmith@example.com", time: "1m 45s" },
                { id: "efgh5678", user: "jsmith@example.com", time: "2m 12s" },
                { id: "ijkl9101", user: "emily@example.com", time: "58s" },
              ].map((row, i) => (
                <tr key={i} className="border-b border-border/50 hover:bg-secondary/20 transition-colors">
                  <td className="px-5 py-3 text-sm text-foreground font-mono">{row.id}</td>
                  <td className="px-5 py-3 text-sm text-muted-foreground">{row.user}</td>
                  <td className="px-5 py-3 text-sm text-foreground">{row.time}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}