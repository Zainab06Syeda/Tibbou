import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine,
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell
} from "recharts";
import { cn } from "@/lib/utils";

const DAILY_DATA = [
  { day: "Mon", cost: 110 },
  { day: "Tue", cost: 145 },
  { day: "Wed", cost: 170 },
  { day: "Thu", cost: 165 },
  { day: "Fri", cost: 255 },
  { day: "Sat", cost: 260 },
  { day: "Sat", cost: 275 },
  { day: "Sun", cost: 268 },
];

const TOP_QUERIES = [
  { query_id: "Q1934", user_name: "analytics_user", warehouse_name: "WH_L", duration_ms: 12000, credits_used: 4.32 },
  { query_id: "Q2031", user_name: "data_engineer", warehouse_name: "WH_XL", duration_ms: 22000, credits_used: 6.10 },
  { query_id: "Q2201", user_name: "analyst_user", warehouse_name: "WH_M", duration_ms: 5000, credits_used: 1.20 },
  { query_id: "Q3013", user_name: "data_scientist", warehouse_name: "WH_XL", duration_ms: 35000, credits_used: 6.80 },
];

const PIE_COLORS = ["hsl(187,92%,41%)", "hsl(160,84%,39%)", "hsl(38,92%,50%)", "hsl(270,70%,60%)", "hsl(340,75%,55%)"];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-xl text-xs">
      <p className="text-muted-foreground mb-1">{label}</p>
      {payload.map((e, i) => (
        <p key={i} style={{ color: e.color }}>{e.name}: ${e.value?.toFixed ? e.value.toFixed(2) : e.value}</p>
      ))}
    </div>
  );
};

export default function CostTracking() {
  const [summaries, setSummaries] = useState([]);
  const [queries, setQueries] = useState([]);
  const [dateRange, setDateRange] = useState("7d");
  const [groupBy, setGroupBy] = useState("daily");
  const [filterWarehouse, setFilterWarehouse] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [s, q] = await Promise.all([
        base44.entities.CostSummary.list("-period", 100),
        base44.entities.SnowflakeQuery.list("-start_time", 20),
      ]);
      setSummaries(s);
      setQueries(q);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const totalCost = summaries.reduce((s, c) => s + (c.total_cost_usd || 0), 0);
  const displayCost = totalCost > 0 ? totalCost : 1248.30;

  // Cost by warehouse for pie
  const warehouseCosts = {};
  summaries.forEach(s => {
    if (!warehouseCosts[s.warehouse_name]) warehouseCosts[s.warehouse_name] = 0;
    warehouseCosts[s.warehouse_name] += s.total_cost_usd || 0;
  });
  const pieData = Object.entries(warehouseCosts).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) }));

  const topQueries = queries.length > 0
    ? [...queries].sort((a, b) => (b.credits_used || 0) - (a.credits_used || 0)).slice(0, 4)
    : TOP_QUERIES;

  const avgDay = DAILY_DATA.reduce((s, d) => s + d.cost, 0) / DAILY_DATA.length;
  const warehouses = [...new Set(summaries.map(s => s.warehouse_name).filter(Boolean))];

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold text-foreground tracking-tight">Cost Analysis</h1>

      {/* Filter bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Date Range</span>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="h-8 text-xs bg-card border-border w-[120px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="1d">Last 1 Day</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Warehouse</span>
          <Select value={filterWarehouse} onValueChange={setFilterWarehouse}>
            <SelectTrigger className="h-8 text-xs bg-card border-border w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Warehouse</SelectItem>
              {warehouses.map(w => <SelectItem key={w} value={w}>{w}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Group By:</span>
          <Select value={groupBy} onValueChange={setGroupBy}>
            <SelectTrigger className="h-8 text-xs bg-card border-border w-[90px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button variant="ghost" size="sm" className="ml-auto text-xs text-muted-foreground h-8"
          onClick={() => { setDateRange("7d"); setFilterWarehouse("all"); setGroupBy("daily"); }}>
          Clear All
        </Button>
      </div>

      {/* Total Cost Stat */}
      <div className="bg-card border border-border rounded-xl px-6 py-5">
        <p className="text-4xl font-bold text-foreground">${displayCost.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        <p className="text-sm text-muted-foreground mt-1">Total Cost (Last 7 Days)</p>
        <div className="flex items-center gap-1 mt-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-xs text-emerald-400 font-medium">8.3% vs Last 7 Days</span>
        </div>
      </div>

      {/* Daily Snowflake Cost Line Chart */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">Daily Snowflake Cost</h2>
        <div className="h-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={DAILY_DATA} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="day" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={{ stroke: "hsl(var(--border))" }} tickLine={false} />
              <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={avgDay} stroke="hsl(var(--muted-foreground))" strokeDasharray="4 4"
                label={{ value: `$${avgDay.toFixed(0)} Avg/Day`, position: "insideBottomLeft", fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
              <Line type="monotone" dataKey="cost" name="Snowflake Cost" stroke="hsl(var(--foreground))" strokeWidth={2} dot={{ r: 3, fill: "hsl(var(--foreground))" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <div className="w-6 h-0.5 bg-foreground" />
          <span className="text-xs text-muted-foreground">Snowflake Cost</span>
        </div>
      </div>

      {/* Top Expensive Queries */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground">Top Expensive Queries</h2>
          <button className="text-xs text-primary hover:underline">View All</button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-secondary/20">
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Query ID</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">User</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Warehouse</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Execution Time</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Cost</th>
            </tr>
          </thead>
          <tbody>
            {topQueries.map((q, i) => (
              <tr key={q.id || i} className="border-b border-border/50 hover:bg-secondary/20 transition-colors">
                <td className="px-5 py-3 text-sm font-mono text-foreground">{q.query_id}</td>
                <td className="px-5 py-3 text-sm text-muted-foreground">{q.user_name}</td>
                <td className="px-5 py-3 text-sm text-muted-foreground">{q.warehouse_name}</td>
                <td className="px-5 py-3 text-sm text-foreground">{q.duration_ms ? `${Math.round(q.duration_ms / 1000)}s` : "—"}</td>
                <td className="px-5 py-3 text-sm text-foreground">${(q.credits_used || 0).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Existing warehouse breakdown charts */}
      {pieData.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Cost by Warehouse</h3>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={4} dataKey="value">
                    {pieData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-1.5 mt-2">
              {pieData.map((w, i) => (
                <div key={w.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                    <span className="text-muted-foreground">{w.name}</span>
                  </div>
                  <span className="text-foreground font-mono">${w.value.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Credits by Warehouse</h3>
            <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={Object.entries(warehouseCosts).map(([name, cost]) => ({ name, cost }))} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(217,19%,20%)" />
                  <XAxis dataKey="name" tick={{ fill: "hsl(215,20%,65%)", fontSize: 11 }} axisLine={{ stroke: "hsl(217,19%,20%)" }} tickLine={false} />
                  <YAxis tick={{ fill: "hsl(215,20%,65%)", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="cost" name="Cost ($)" fill="hsl(187,92%,41%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}