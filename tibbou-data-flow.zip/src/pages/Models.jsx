import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, X, AlertTriangle, Database, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import moment from "moment";

const SAMPLE_MODELS = [
  { model_name: "orders_raw", schema_name: "analytics", materialization: "table", updated_date: new Date(Date.now() - 2 * 3600000).toISOString(), depends_on: ["raw_events"], columns_count: 12 },
  { model_name: "orders_clean", schema_name: "analytics", materialization: "table", updated_date: new Date(Date.now() - 2 * 86400000).toISOString(), depends_on: ["orders_raw", "dim_customers", "dim_products", "ref_currency"], columns_count: 24 },
  { model_name: "orders_summary", schema_name: "analytics", materialization: "table", updated_date: new Date(Date.now() - 2 * 86400000).toISOString(), depends_on: ["orders_clean", "orders_raw", "dim_date", "fct_revenue", "ref_currency", "ref_region"], columns_count: 18 },
  { model_name: "orders_dashboard_model", schema_name: "dashboards", materialization: "table", updated_date: new Date(Date.now() - 3 * 86400000).toISOString(), depends_on: ["orders_summary", "dim_customers", "ref_currency"], columns_count: 32 },
];

const SAMPLE_ALERTS = [
  { msg: "Long running query Q3057 has been executing for 14m", time: "2h ago" },
  { msg: "Source table raw_events failed to refresh", time: "2h ago" },
  { msg: "Warehouse WH_XL reached 95% credit quota", time: "4h ago" },
  { msg: "Upstream data dependency error detected in orders_tomslomed report_sales", time: "6h ago", link: "View" },
  { msg: "Long running query Q3057 has been executing for 14m", time: "6h ago" },
];

const DOWNSTREAM_DEPS = [
  { name: "orders_clean", deps: 4 },
  { name: "orders_summary", deps: 5 },
  { name: "orders_dashboard_model", deps: 3 },
  { name: "orders_dashboard", deps: 8 },
];

export default function Models() {
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterSchema, setFilterSchema] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedModel, setSelectedModel] = useState(null);
  const [depTab, setDepTab] = useState("downstream");

  useEffect(() => {
    async function load() {
      const data = await base44.entities.DbtModel.list("-created_date", 200);
      setModels(data.length > 0 ? data : SAMPLE_MODELS);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const schemas = [...new Set(models.map(m => m.schema_name).filter(Boolean))];
  const types = [...new Set(models.map(m => m.materialization).filter(Boolean))];

  const filtered = models.filter(m => {
    const matchSearch = !search || m.model_name?.toLowerCase().includes(search.toLowerCase());
    const matchSchema = filterSchema === "all" || m.schema_name === filterSchema;
    const matchType = filterType === "all" || m.materialization === filterType;
    return matchSearch && matchSchema && matchType;
  });

  const activeModel = selectedModel || filtered[0];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-foreground tracking-tight">Metadata Explorer</h1>

      {/* Search bar */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search tables, models, columns..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 pr-9 bg-card border-border"
          />
          {search && (
            <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        {search && (
          <Button variant="ghost" size="sm" className="text-muted-foreground" onClick={() => setSearch("")}>Clear</Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Schema:</span>
          <Select value={filterSchema} onValueChange={setFilterSchema}>
            <SelectTrigger className="h-7 text-xs bg-card border-border w-[110px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {schemas.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Type:</span>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="h-7 text-xs bg-card border-border w-[110px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {types.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Status:</span>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="h-7 text-xs bg-card border-border w-[110px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="healthy">Healthy</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Two-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Search Results */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Search Results</h2>
          </div>

          {/* Table */}
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/20">
                <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Name</th>
                <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Schema</th>
                <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Type</th>
                <th className="text-left text-xs font-medium text-muted-foreground px-5 py-2.5">Last Updated</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m, i) => (
                <tr
                  key={m.id || i}
                  onClick={() => setSelectedModel(m)}
                  className={cn(
                    "border-b border-border/50 cursor-pointer transition-colors",
                    activeModel?.model_name === m.model_name ? "bg-primary/5" : "hover:bg-secondary/30"
                  )}
                >
                  <td className="px-5 py-3">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-foreground">{m.model_name}</p>
                        <p className="text-xs text-muted-foreground">{m.depends_on?.length || 0} Dependencies</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-sm text-muted-foreground">{m.schema_name || "—"}</td>
                  <td className="px-5 py-3 text-sm text-muted-foreground capitalize">{m.materialization || "—"}</td>
                  <td className="px-5 py-3 text-sm text-muted-foreground">{m.updated_date ? moment(m.updated_date).fromNow() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Alerts section */}
          <div className="border-t border-border">
            {SAMPLE_ALERTS.map((a, i) => (
              <div key={i} className="flex items-start gap-2 px-5 py-2.5 border-b border-border/40 hover:bg-secondary/20 transition-colors">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground flex-1">
                  {a.msg}
                  {a.link && <button className="ml-1 text-primary underline">{a.link}</button>}
                </p>
                <span className="text-xs text-muted-foreground flex-shrink-0">{a.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Dependency Details */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-border flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground">Dependency Details</h2>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-border">
            {["downstream", "upstream"].map(t => (
              <button
                key={t}
                onClick={() => setDepTab(t)}
                className={cn(
                  "flex-1 py-2 text-xs font-medium transition-colors capitalize",
                  depTab === t ? "text-foreground border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>

          <div className="p-4 space-y-3">
            {activeModel && (
              <>
                <p className="text-xs font-medium text-foreground">If <span className="text-primary">{activeModel.model_name}</span> changes</p>
                <div className="bg-secondary/40 rounded-md px-3 py-1.5">
                  <p className="text-xs text-muted-foreground">Directly impacted</p>
                </div>
                <div className="space-y-2">
                  {DOWNSTREAM_DEPS.map((d, i) => (
                    <div key={i} className="flex items-center gap-2 px-2 py-2 rounded-lg hover:bg-secondary/30 transition-colors cursor-pointer">
                      <Database className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                      <div>
                        <p className="text-xs font-medium text-foreground">{d.name}</p>
                        <p className="text-[10px] text-muted-foreground">{d.deps} Dependencies</p>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="text-xs text-primary hover:underline flex items-center gap-1 pt-2">
                  View All Resolved Alerts <ArrowRight className="w-3 h-3" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}