import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import LineageGraph from "../components/LineageGraph";
import { Input } from "@/components/ui/input";
import { Search, Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Lineage() {
  const [edges, setEdges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("all");

  useEffect(() => {
    async function load() {
      const data = await base44.entities.LineageEdge.list("-created_date", 200);
      setEdges(data);
      setLoading(false);
    }
    load();
  }, []);

  const filteredEdges = edges.filter((e) => {
    const matchesSearch = !search || 
      e.source_node?.toLowerCase().includes(search.toLowerCase()) ||
      e.target_node?.toLowerCase().includes(search.toLowerCase());
    const matchesType = filterType === "all" || 
      e.source_type === filterType || 
      e.target_type === filterType;
    return matchesSearch && matchesType;
  });

  // Collect unique node types
  const nodeTypes = [...new Set([
    ...edges.map(e => e.source_type),
    ...edges.map(e => e.target_type)
  ])].filter(Boolean);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Data Lineage</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Visualize how data flows from sources through dbt models to downstream consumers
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search nodes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-card border-border"
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-[160px] bg-card border-border">
            <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {nodeTypes.map(t => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Stats */}
      <div className="flex gap-4 text-sm">
        <div className="bg-card border border-border rounded-lg px-4 py-2">
          <span className="text-muted-foreground">Edges: </span>
          <span className="text-foreground font-semibold">{filteredEdges.length}</span>
        </div>
        <div className="bg-card border border-border rounded-lg px-4 py-2">
          <span className="text-muted-foreground">Nodes: </span>
          <span className="text-foreground font-semibold">
            {new Set([...filteredEdges.map(e => e.source_node), ...filteredEdges.map(e => e.target_node)]).size}
          </span>
        </div>
      </div>

      {/* Graph */}
      <LineageGraph edges={filteredEdges} />
    </div>
  );
}