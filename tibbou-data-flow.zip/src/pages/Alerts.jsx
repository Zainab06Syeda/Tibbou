import { Bell, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const ALERTS = [
  { id: 1, title: "fct_revenue run failed", desc: "Merge conflict: duplicate keys found in source data for 2026-03-09", time: "2 min ago", type: "error", resolved: false },
  { id: 2, title: "High credit usage detected", desc: "ETL_WH used 25.6 credits today — 40% above average", time: "1 hour ago", type: "warning", resolved: false },
  { id: 3, title: "Snowflake sync complete", desc: "COMPUTE_WH synced 245 queries successfully", time: "2 hours ago", type: "success", resolved: true },
  { id: 4, title: "dbt run started", desc: "Pipeline tibbou_dbt kicked off — 8 models queued", time: "3 hours ago", type: "info", resolved: true },
  { id: 5, title: "rpt_daily_sales skipped", desc: "Skipped due to upstream failure in fct_revenue", time: "5 hours ago", type: "warning", resolved: false },
];

const typeConfig = {
  error: { icon: AlertTriangle, className: "text-red-400 bg-red-500/10 border-red-500/20", dot: "bg-red-400", badge: "bg-red-500/10 text-red-400 border-red-500/20" },
  warning: { icon: AlertTriangle, className: "text-amber-400 bg-amber-500/10 border-amber-500/20", dot: "bg-amber-400", badge: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  success: { icon: CheckCircle, className: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20", dot: "bg-emerald-400", badge: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  info: { icon: Info, className: "text-blue-400 bg-blue-500/10 border-blue-500/20", dot: "bg-blue-400", badge: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
};

export default function Alerts() {
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Alerts</h1>
          <p className="text-sm text-muted-foreground mt-1">Pipeline failures, cost anomalies, and system notifications</p>
        </div>
        <div className="flex gap-2">
          {["error", "warning"].map(t => (
            <Badge key={t} variant="outline" className={cn("text-xs", typeConfig[t].badge)}>
              {ALERTS.filter(a => a.type === t && !a.resolved).length} {t}s
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {ALERTS.map(alert => {
          const cfg = typeConfig[alert.type];
          const Icon = cfg.icon;
          return (
            <div key={alert.id} className={cn("bg-card border rounded-xl p-5 flex items-start gap-4", alert.resolved ? "border-border opacity-60" : "border-border")}>
              <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 border", cfg.className)}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-semibold text-foreground">{alert.title}</p>
                  {alert.resolved && (
                    <Badge variant="outline" className="text-[10px] text-muted-foreground border-border">Resolved</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">{alert.desc}</p>
              </div>
              <span className="text-xs text-muted-foreground flex-shrink-0">{alert.time}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}