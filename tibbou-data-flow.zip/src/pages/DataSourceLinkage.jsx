import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Plus, Settings, MoreHorizontal, Database, RefreshCw,
  CheckCircle, XCircle, AlertCircle, Loader2, Upload, Server
} from "lucide-react";
import { cn } from "@/lib/utils";
import moment from "moment";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

const sourceTypeConfig = {
  snowflake: { label: "Snowflake", color: "text-cyan-400", bg: "bg-cyan-500/10", icon: "❄️" },
  dbt: { label: "dbt", color: "text-orange-400", bg: "bg-orange-500/10", icon: "✳️" },
  bigquery: { label: "BigQuery", color: "text-blue-400", bg: "bg-blue-500/10", icon: "🔵" },
  s3: { label: "S3", color: "text-amber-400", bg: "bg-amber-500/10", icon: "🪣" },
  file_upload: { label: "File Upload", color: "text-purple-400", bg: "bg-purple-500/10", icon: "📄" },
  redshift: { label: "Redshift", color: "text-red-400", bg: "bg-red-500/10", icon: "🔴" },
  postgres: { label: "PostgreSQL", color: "text-blue-300", bg: "bg-blue-400/10", icon: "🐘" },
};

const statusConfig = {
  connected: { label: "Connected", className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20", dot: "bg-emerald-400" },
  disconnected: { label: "Disconnected", className: "bg-slate-500/10 text-slate-400 border-slate-500/20", dot: "bg-slate-400" },
  error: { label: "Error", className: "bg-red-500/10 text-red-400 border-red-500/20", dot: "bg-red-400" },
};

const newSourceTypes = [
  { type: "snowflake", label: "Snowflake Warehouse", desc: "Connect to Snowflake data warehouse" },
  { type: "dbt", label: "dbt Project", desc: "Import dbt manifest and run results" },
  { type: "bigquery", label: "Google BigQuery", desc: "Connect to BigQuery datasets" },
  { type: "s3", label: "AWS S3 Bucket", desc: "Read metadata from S3 storage" },
  { type: "file_upload", label: "CSV / File Upload", desc: "Upload files manually" },
  { type: "redshift", label: "Amazon Redshift", desc: "Connect to Redshift cluster" },
  { type: "postgres", label: "PostgreSQL", desc: "Connect to Postgres database" },
];

function AddSourceForm({ onSave, onCancel }) {
  const [step, setStep] = useState(1);
  const [selectedType, setSelectedType] = useState(null);
  const [form, setForm] = useState({ source_name: "", identifier: "" });
  const [saving, setSaving] = useState(false);

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  async function handleSave() {
    setSaving(true);
    const user = await base44.auth.me();
    await onSave({
      ...form,
      source_type: selectedType,
      status: "disconnected",
      user_email: user.email,
      total_syncs_today: 0,
    });
    setSaving(false);
  }

  if (step === 1) {
    return (
      <div className="bg-card border border-border rounded-xl p-6">
        <h3 className="text-base font-semibold text-foreground mb-1">Add New Data Source</h3>
        <p className="text-xs text-muted-foreground mb-5">Choose the type of data source to connect</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {newSourceTypes.map((s) => {
            const cfg = sourceTypeConfig[s.type];
            return (
              <button
                key={s.type}
                onClick={() => { setSelectedType(s.type); setStep(2); }}
                className={cn(
                  "text-left p-4 rounded-xl border transition-all hover:border-primary/40",
                  "bg-secondary/50 border-border hover:bg-secondary"
                )}
              >
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center text-lg mb-2", cfg.bg)}>
                  {cfg.icon}
                </div>
                <p className="text-sm font-medium text-foreground">{s.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.desc}</p>
              </button>
            );
          })}
        </div>
        <Button onClick={onCancel} variant="ghost" className="mt-4 text-muted-foreground">Cancel</Button>
      </div>
    );
  }

  const cfg = sourceTypeConfig[selectedType];
  return (
    <div className="bg-card border border-border rounded-xl p-6 max-w-lg space-y-4">
      <div className="flex items-center gap-3 mb-2">
        <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center text-lg", cfg.bg)}>{cfg.icon}</div>
        <div>
          <h3 className="text-base font-semibold text-foreground">Configure {cfg.label}</h3>
          <p className="text-xs text-muted-foreground">Enter the connection details</p>
        </div>
      </div>
      <div className="space-y-3">
        <div className="space-y-1.5">
          <Label className="text-sm text-muted-foreground">Source Name</Label>
          <Input placeholder={`My ${cfg.label}`} value={form.source_name} onChange={e => update("source_name", e.target.value)} className="bg-secondary border-border" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-sm text-muted-foreground">Identifier / Handle</Label>
          <Input placeholder="e.g. prod_wh, tibbou_dbt" value={form.identifier} onChange={e => update("identifier", e.target.value)} className="bg-secondary border-border" />
        </div>
      </div>
      <div className="flex items-center gap-3 pt-2">
        <Button onClick={handleSave} disabled={!form.source_name || saving} className="bg-primary text-primary-foreground">
          {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
          Add Source
        </Button>
        <Button onClick={() => setStep(1)} variant="outline" className="border-border">Back</Button>
        <Button onClick={onCancel} variant="ghost" className="text-muted-foreground ml-auto">Cancel</Button>
      </div>
    </div>
  );
}

export default function DataSourceLinkage() {
  const [sources, setSources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("connected");
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    async function load() {
      const data = await base44.entities.DataSource.list("-created_date", 100);
      setSources(data);
      setLoading(false);
    }
    load();
  }, []);

  async function handleAdd(data) {
    const created = await base44.entities.DataSource.create(data);
    setSources(prev => [created, ...prev]);
    setShowAddForm(false);
    setActiveTab("connected");
  }

  async function handleDelete(id) {
    await base44.entities.DataSource.delete(id);
    setSources(prev => prev.filter(s => s.id !== id));
  }

  async function handleSync(source) {
    await base44.entities.DataSource.update(source.id, {
      last_synced_at: new Date().toISOString(),
      total_syncs_today: (source.total_syncs_today || 0) + 1,
      status: "connected",
    });
    setSources(prev => prev.map(s => s.id === source.id
      ? { ...s, last_synced_at: new Date().toISOString(), total_syncs_today: (s.total_syncs_today || 0) + 1, status: "connected" }
      : s
    ));
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const connected = sources.filter(s => s.status === "connected");
  const disconnected = sources.filter(s => s.status !== "connected");
  const totalSyncs = sources.reduce((sum, s) => sum + (s.total_syncs_today || 0), 0);

  const shownSources = activeTab === "connected" ? sources : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Data Sources Linkage</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Connect and manage your data sources (Snowflake, dbt, and more).
          </p>
        </div>
        <Button
          onClick={() => { setShowAddForm(true); setActiveTab("add"); }}
          className="bg-primary text-primary-foreground flex-shrink-0"
        >
          <Plus className="w-4 h-4 mr-1.5" /> Add Data Source
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-border">
        {[
          { key: "connected", label: "Connected Sources" },
          { key: "add", label: "Add New Source" },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => { setActiveTab(tab.key); if (tab.key === "add") setShowAddForm(true); else setShowAddForm(false); }}
            className={cn(
              "px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px",
              activeTab === tab.key
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Add Form */}
      {showAddForm && (
        <AddSourceForm
          onSave={handleAdd}
          onCancel={() => { setShowAddForm(false); setActiveTab("connected"); }}
        />
      )}

      {/* Sources Table */}
      {!showAddForm && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Source Name</th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Type</th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Status</th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Last Synced</th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sources.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-5 py-12 text-center">
                      <Server className="w-10 h-10 text-muted-foreground/20 mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">No data sources yet</p>
                      <p className="text-xs text-muted-foreground/60 mt-1">Click "Add Data Source" to get started</p>
                    </td>
                  </tr>
                )}
                {sources.map((source, i) => {
                  const cfg = sourceTypeConfig[source.source_type] || sourceTypeConfig.snowflake;
                  const sc = statusConfig[source.status] || statusConfig.disconnected;
                  return (
                    <tr key={source.id} className="border-b border-border/50 hover:bg-secondary/20 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-base flex-shrink-0", cfg.bg)}>
                            {cfg.icon}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-foreground">{source.source_name}</p>
                            {source.identifier && (
                              <p className="text-xs text-muted-foreground">{source.identifier}</p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <span className={cn("text-sm font-medium", cfg.color)}>{cfg.label}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <div className={cn("w-2 h-2 rounded-full", sc.dot)} />
                          <span className={cn("text-sm", source.status === "connected" ? "text-emerald-400" : "text-muted-foreground")}>
                            {sc.label}
                          </span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <span className="text-sm text-muted-foreground">
                          {source.last_synced_at ? moment(source.last_synced_at).fromNow() : "—"}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          {source.status === "connected" ? (
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-border text-xs h-7 px-3"
                              onClick={() => handleSync(source)}
                            >
                              <RefreshCw className="w-3 h-3 mr-1" /> Sync
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              className="bg-primary text-primary-foreground text-xs h-7 px-3"
                              onClick={() => handleSync(source)}
                            >
                              Connect
                            </Button>
                          )}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="sm" variant="outline" className="border-border h-7 w-7 p-0">
                                <MoreHorizontal className="w-3.5 h-3.5" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="bg-card border-border">
                              <DropdownMenuItem className="text-sm cursor-pointer">
                                <Settings className="w-3.5 h-3.5 mr-2" /> Settings
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-sm text-destructive cursor-pointer"
                                onClick={() => handleDelete(source.id)}
                              >
                                Remove Source
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Connection Overview */}
      {!showAddForm && (
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Connection Overview</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Total Sources", value: sources.length, icon: "🗄️", color: "text-foreground" },
              { label: "Connected", value: connected.length, icon: "🟢", color: "text-emerald-400" },
              { label: "Disconnected", value: disconnected.length, icon: "⚫", color: "text-muted-foreground" },
              { label: "Total Syncs Today", value: totalSyncs, icon: "🔄", color: "text-primary" },
            ].map((stat) => (
              <div key={stat.label} className="bg-secondary/40 rounded-lg px-4 py-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-base">{stat.icon}</span>
                  <p className={cn("text-2xl font-bold", stat.color)}>{stat.value}</p>
                </div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}