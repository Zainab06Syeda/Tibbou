import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Wifi, WifiOff, Plus, Trash2, CheckCircle, AlertCircle, Eye, EyeOff, Database } from "lucide-react";
import { cn } from "@/lib/utils";
import moment from "moment";

// ─── Snowflake Connection Form ───────────────────────────────────────────────
function ConnectionForm({ onSave, onCancel }) {
  const [form, setForm] = useState({ connection_name: "", account_identifier: "", username: "", password: "", warehouse: "", database: "", schema_name: "", role: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [saving, setSaving] = useState(false);
  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  async function handleTest() {
    setTesting(true); setTestResult(null);
    const res = await base44.functions.invoke("testSnowflakeConnection", { account_identifier: form.account_identifier, username: form.username, password: form.password, warehouse: form.warehouse, database: form.database, role: form.role });
    setTestResult(res.data); setTesting(false);
  }

  async function handleSave() {
    setSaving(true);
    const user = await base44.auth.me();
    await onSave({ ...form, user_email: user.email, is_active: true, connection_status: testResult?.success ? "connected" : "untested", last_tested_at: testResult ? new Date().toISOString() : undefined });
    setSaving(false);
  }

  const isValid = form.account_identifier && form.username && form.password;

  return (
    <div className="bg-secondary/30 border border-border rounded-xl p-5 space-y-4 mt-4">
      <h3 className="text-sm font-semibold text-foreground">New Snowflake Connection</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2 space-y-1.5">
          <Label className="text-xs text-muted-foreground">Connection Name</Label>
          <Input placeholder="My Snowflake Account" value={form.connection_name} onChange={e => update("connection_name", e.target.value)} className="bg-secondary border-border" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Account Identifier <span className="text-destructive">*</span></Label>
          <Input placeholder="myorg-myaccount" value={form.account_identifier} onChange={e => update("account_identifier", e.target.value)} className="bg-secondary border-border" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Role</Label>
          <Input placeholder="ACCOUNTADMIN" value={form.role} onChange={e => update("role", e.target.value)} className="bg-secondary border-border" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Username <span className="text-destructive">*</span></Label>
          <Input placeholder="snowflake_user" value={form.username} onChange={e => update("username", e.target.value)} className="bg-secondary border-border" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Password <span className="text-destructive">*</span></Label>
          <div className="relative">
            <Input type={showPassword ? "text" : "password"} placeholder="••••••••" value={form.password} onChange={e => update("password", e.target.value)} className="bg-secondary border-border pr-10" />
            <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Warehouse</Label>
          <Input placeholder="COMPUTE_WH" value={form.warehouse} onChange={e => update("warehouse", e.target.value)} className="bg-secondary border-border" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Database</Label>
          <Input placeholder="ANALYTICS" value={form.database} onChange={e => update("database", e.target.value)} className="bg-secondary border-border" />
        </div>
      </div>

      {testResult && (
        <div className={cn("rounded-lg p-3 border text-sm", testResult.success ? "bg-emerald-500/10 border-emerald-500/20" : "bg-red-500/10 border-red-500/20")}>
          {testResult.success ? (
            <div className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5" />
              <div>
                <p className="text-emerald-400 font-medium text-xs">Connection successful!</p>
                <p className="text-muted-foreground text-xs mt-0.5">User: {testResult.current_user} · WH: {testResult.current_warehouse}</p>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5" />
              <p className="text-red-400 text-xs">{testResult.error}</p>
            </div>
          )}
        </div>
      )}

      <div className="flex items-center gap-3 pt-1">
        <Button onClick={handleTest} variant="outline" disabled={!isValid || testing} size="sm" className="border-border">
          {testing ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Wifi className="w-4 h-4 mr-1" />}
          Test Connection
        </Button>
        <Button onClick={handleSave} disabled={!isValid || saving} size="sm" className="bg-primary text-primary-foreground">
          {saving && <Loader2 className="w-4 h-4 animate-spin mr-1" />} Save
        </Button>
        <Button onClick={onCancel} variant="ghost" size="sm" className="text-muted-foreground ml-auto">Cancel</Button>
      </div>
    </div>
  );
}

// ─── Connections Tab ──────────────────────────────────────────────────────────
function ConnectionsTab() {
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [testing, setTesting] = useState(null);

  useEffect(() => {
    async function load() {
      const u = await base44.auth.me();
      const conns = await base44.entities.SnowflakeConnection.filter({ user_email: u.email });
      setConnections(conns);
      setLoading(false);
    }
    load();
  }, []);

  async function handleSave(data) {
    const conn = await base44.entities.SnowflakeConnection.create(data);
    setConnections(prev => [...prev, conn]);
    setShowForm(false);
  }

  async function handleDelete(id) {
    await base44.entities.SnowflakeConnection.delete(id);
    setConnections(prev => prev.filter(c => c.id !== id));
  }

  async function handleTest(conn) {
    setTesting(conn.id);
    const res = await base44.functions.invoke("testSnowflakeConnection", { account_identifier: conn.account_identifier, username: conn.username, password: conn.password, warehouse: conn.warehouse, database: conn.database, role: conn.role });
    const status = res.data?.success ? "connected" : "failed";
    await base44.entities.SnowflakeConnection.update(conn.id, { connection_status: status, last_tested_at: new Date().toISOString() });
    setConnections(prev => prev.map(c => c.id === conn.id ? { ...c, connection_status: status, last_tested_at: new Date().toISOString() } : c));
    setTesting(null);
  }

  async function setActive(conn) {
    await Promise.all(connections.map(c => base44.entities.SnowflakeConnection.update(c.id, { is_active: c.id === conn.id })));
    setConnections(prev => prev.map(c => ({ ...c, is_active: c.id === conn.id })));
  }

  const statusConfig = {
    connected: { label: "Connected", className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20", icon: CheckCircle },
    failed: { label: "Failed", className: "bg-red-500/10 text-red-400 border-red-500/20", icon: AlertCircle },
    untested: { label: "Untested", className: "bg-amber-500/10 text-amber-400 border-amber-500/20", icon: WifiOff },
  };

  if (loading) return <div className="flex items-center justify-center h-32"><div className="w-6 h-6 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">Snowflake Connections</h2>
          <Badge variant="outline" className="text-xs border-border text-muted-foreground">{connections.length}</Badge>
        </div>
        {!showForm && (
          <Button onClick={() => setShowForm(true)} size="sm" className="bg-primary text-primary-foreground">
            <Plus className="w-4 h-4 mr-1" /> Add Connection
          </Button>
        )}
      </div>

      {showForm && <ConnectionForm onSave={handleSave} onCancel={() => setShowForm(false)} />}

      {connections.length === 0 && !showForm && (
        <div className="bg-card border border-dashed border-border rounded-xl p-10 text-center">
          <Database className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">No Snowflake connections yet</p>
          <p className="text-muted-foreground/60 text-xs mt-1">Add a connection to start analyzing your data lineage and costs</p>
          <Button onClick={() => setShowForm(true)} size="sm" className="mt-4 bg-primary text-primary-foreground">
            <Plus className="w-4 h-4 mr-1" /> Add Connection
          </Button>
        </div>
      )}

      <div className="space-y-3">
        {connections.map(conn => {
          const sc = statusConfig[conn.connection_status || "untested"];
          const StatusIcon = sc.icon;
          return (
            <div key={conn.id} className={cn("bg-card border rounded-xl p-5 transition-all", conn.is_active ? "border-primary/40" : "border-border")}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center mt-0.5", conn.connection_status === "connected" ? "bg-emerald-500/10" : "bg-secondary")}>
                    <Database className={cn("w-4 h-4", conn.connection_status === "connected" ? "text-emerald-400" : "text-muted-foreground")} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-foreground">{conn.connection_name || conn.account_identifier}</p>
                      {conn.is_active && <Badge variant="outline" className="text-[10px] bg-primary/10 border-primary/30 text-primary">Active</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{conn.account_identifier} · {conn.username}{conn.warehouse ? ` · ${conn.warehouse}` : ""}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className={cn("text-xs", sc.className)}>
                        <StatusIcon className="w-3 h-3 mr-1" />{sc.label}
                      </Badge>
                      {conn.last_tested_at && <span className="text-[10px] text-muted-foreground">Tested {moment(conn.last_tested_at).fromNow()}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {!conn.is_active && (
                    <Button size="sm" variant="outline" className="border-border text-xs" onClick={() => setActive(conn)}>Set Active</Button>
                  )}
                  <Button size="sm" variant="outline" className="border-border text-xs" onClick={() => handleTest(conn)} disabled={testing === conn.id}>
                    {testing === conn.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wifi className="w-3 h-3" />}
                  </Button>
                  <Button size="sm" variant="outline" className="border-border text-destructive hover:text-destructive" onClick={() => handleDelete(conn.id)}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Main Settings Page ───────────────────────────────────────────────────────
export default function Settings() {
  const [tab, setTab] = useState("general");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [twoFA, setTwoFA] = useState(false);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [org, setOrg] = useState("America/New_York");
  const [theme, setTheme] = useState("Dark");
  const [costThreshold, setCostThreshold] = useState("100");
  const [costAnomaly, setCostAnomaly] = useState(true);
  const [failedJobs, setFailedJobs] = useState(true);
  const [username, setUsername] = useState("");

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setFullName(u.full_name || "");
      setEmail(u.email || "");
      setUsername(u.email?.split("@")[0] || "");
      setLoading(false);
    });
  }, []);

  async function handleSave() {
    setSaving(true);
    await base44.auth.updateMe({ full_name: fullName });
    setSaving(false); setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
    </div>
  );

  const initials = fullName.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
  const TABS = [
    { id: "general", label: "General Settings" },
    { id: "account", label: "Account Settings" },
    { id: "connections", label: "Connections" },
  ];


  return (
    <div className="max-w-4xl space-y-6">
      <h1 className="text-2xl font-bold text-foreground tracking-tight">Settings</h1>

      {/* Tabs */}
      <div className="flex gap-0 border-b border-border">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn("px-5 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors",
              tab === t.id ? "border-foreground text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
            )}>
            {t.label}
          </button>
        ))}
      </div>

      {/* General Settings */}
      {tab === "general" && (
        <div className="max-w-md space-y-8">
          {/* General Settings section */}
          <div className="space-y-4">
            <h2 className="text-base font-semibold text-foreground">General Settings</h2>
            <div className="space-y-1.5">
              <Label className="text-sm text-muted-foreground">Time Zone</Label>
              <Select value={org} onValueChange={setOrg}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="America/New_York">America/New_York</SelectItem>
                  <SelectItem value="America/Chicago">America/Chicago</SelectItem>
                  <SelectItem value="America/Denver">America/Denver</SelectItem>
                  <SelectItem value="America/Los_Angeles">America/Los_Angeles</SelectItem>
                  <SelectItem value="UTC">UTC</SelectItem>
                  <SelectItem value="Europe/London">Europe/London</SelectItem>
                  <SelectItem value="Europe/Paris">Europe/Paris</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm text-muted-foreground">Theme</Label>
              <Select value={theme} onValueChange={setTheme}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Dark">Dark</SelectItem>
                  <SelectItem value="Light">Light</SelectItem>
                  <SelectItem value="System">System</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Alerts section */}
          <div className="space-y-4">
            <h2 className="text-base font-semibold text-foreground">Alerts</h2>
            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Query Cost Threshold</Label>
              <Select value={costThreshold} onValueChange={setCostThreshold}>
                <SelectTrigger className="w-36 bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="50">$ 50.00</SelectItem>
                  <SelectItem value="100">$ 100.00</SelectItem>
                  <SelectItem value="250">$ 250.00</SelectItem>
                  <SelectItem value="500">$ 500.00</SelectItem>
                  <SelectItem value="1000">$ 1,000.00</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between py-1">
              <Label className="text-sm text-foreground">Cost Anomaly Detection</Label>
              <Switch checked={costAnomaly} onCheckedChange={setCostAnomaly} />
            </div>
            <div className="flex items-center justify-between py-1">
              <Label className="text-sm text-foreground">Failed Job Notifications</Label>
              <Switch checked={failedJobs} onCheckedChange={setFailedJobs} />
            </div>
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full bg-secondary text-foreground border border-border hover:bg-muted">
            {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
            {saved ? "Saved!" : "Save Changes"}
          </Button>
        </div>
      )}

      {/* Account Settings tab */}
      {tab === "account" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left column */}
          <div className="space-y-6">
            <div>
              <h2 className="text-base font-semibold text-foreground mb-4">Profile</h2>
              <div className="flex items-center gap-4 mb-5">
                <div className="w-14 h-14 rounded-full bg-secondary flex items-center justify-center text-foreground font-bold text-lg flex-shrink-0">
                  {initials || "?"}
                </div>
                <Button variant="outline" size="sm" className="border-border text-sm">Upload New</Button>
              </div>
              <div className="space-y-1.5 mb-4">
                <Label className="text-sm text-muted-foreground">Organization / Team</Label>
                <Select defaultValue="Tibbou Inc.">
                  <SelectTrigger className="bg-secondary border-border"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Tibbou Inc.">Tibbou Inc.</SelectItem>
                    <SelectItem value="Personal">Personal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <h2 className="text-base font-semibold text-foreground mb-4">Account Settings</h2>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-sm text-muted-foreground">Full Name</Label>
                  <Input value={fullName} onChange={e => setFullName(e.target.value)} className="bg-secondary border-border" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm text-muted-foreground">Email</Label>
                  <Input value={email} disabled className="bg-secondary border-border opacity-60" />
                </div>
                <Button onClick={handleSave} disabled={saving} className="bg-secondary text-foreground border border-border hover:bg-muted">
                  {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                  {saved ? "Saved!" : "Save Changes"}
                </Button>
              </div>
            </div>
          </div>

          {/* Right column */}
          <div className="space-y-5">
            <div className="space-y-1.5">
              <Label className="text-sm text-muted-foreground">Full Name</Label>
              <Input value={fullName} onChange={e => setFullName(e.target.value)} className="bg-secondary border-border" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm text-muted-foreground">Username</Label>
              <Input value={username} onChange={e => setUsername(e.target.value)} className="bg-secondary border-border" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm text-muted-foreground">Email Address</Label>
              <Input value={email} disabled className="bg-secondary border-border opacity-60" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm text-muted-foreground">Password</Label>
              <div className="flex items-center gap-3">
                <Input type="password" value="••••••••••" readOnly className="bg-secondary border-border" />
                <Button variant="outline" size="sm" className="border-border text-sm whitespace-nowrap">Change Password</Button>
              </div>
            </div>
            <div className="pt-2">
              <h2 className="text-base font-semibold text-foreground mb-3">Security</h2>
              <div className="flex items-center justify-between py-2">
                <Label className="text-sm text-foreground">Two Factor Authentication</Label>
                <Switch checked={twoFA} onCheckedChange={setTwoFA} />
              </div>
            </div>
            <div className="pt-2">
              <h2 className="text-base font-semibold text-foreground mb-1">Delete Account</h2>
              <p className="text-xs text-muted-foreground mb-3">Permanently remove your account and all associated data.<br />This action cannot be undone.</p>
              <Button variant="outline" size="sm" className="border-border text-destructive hover:text-destructive hover:bg-destructive/10">Delete Account</Button>
            </div>
          </div>
        </div>
      )}

      {/* Connections tab */}
      {tab === "connections" && <ConnectionsTab />}
    </div>
  );
}