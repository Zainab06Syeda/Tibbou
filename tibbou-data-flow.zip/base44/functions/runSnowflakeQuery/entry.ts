import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { connection_id, sql } = body;

    if (!connection_id || !sql) {
      return Response.json({ error: 'Missing connection_id or sql' }, { status: 400 });
    }

    // Load the connection for this user
    const connections = await base44.asServiceRole.entities.SnowflakeConnection.filter({
      id: connection_id,
      user_email: user.email,
    });

    if (!connections.length) {
      return Response.json({ error: 'Connection not found or access denied' }, { status: 404 });
    }

    const conn = connections[0];
    const host = `https://${conn.account_identifier}.snowflakecomputing.com`;
    const credentials = btoa(`${conn.username}:${conn.password}`);

    const payload = {
      statement: sql,
      timeout: 120,
      warehouse: conn.warehouse || undefined,
      database: conn.database || undefined,
      schema: conn.schema_name || undefined,
      role: conn.role || undefined,
    };

    const response = await fetch(`${host}/api/v2/statements`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${credentials}`,
        'X-Snowflake-Authorization-Token-Type': 'BASIC',
        'Accept': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      return Response.json({
        success: false,
        error: data?.message || `HTTP ${response.status}`,
      });
    }

    return Response.json({
      success: true,
      columns: data?.resultSetMetaData?.rowType?.map(c => c.name) || [],
      rows: data?.data || [],
      rowCount: data?.data?.length || 0,
    });

  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});