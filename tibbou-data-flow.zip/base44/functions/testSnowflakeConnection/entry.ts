import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { account_identifier, username, password, warehouse, database, role } = body;

    if (!account_identifier || !username || !password) {
      return Response.json({ error: 'Missing required fields: account_identifier, username, password' }, { status: 400 });
    }

    // Build Snowflake REST API URL
    const host = `https://${account_identifier}.snowflakecomputing.com`;
    const endpoint = `${host}/api/v2/statements`;

    const credentials = btoa(`${username}:${password}`);

    const payload = {
      statement: 'SELECT CURRENT_USER(), CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_VERSION()',
      timeout: 60,
      warehouse: warehouse || undefined,
      database: database || undefined,
      role: role || undefined,
    };

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${credentials}`,
        'X-Snowflake-Authorization-Token-Type': 'BASIC',
        'Accept': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      const errorMsg = data?.message || data?.error || `HTTP ${response.status}`;
      return Response.json({
        success: false,
        error: errorMsg,
        status: response.status,
      });
    }

    const row = data?.data?.[0] || [];
    return Response.json({
      success: true,
      current_user: row[0],
      current_warehouse: row[1],
      current_database: row[2],
      snowflake_version: row[3],
    });

  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});